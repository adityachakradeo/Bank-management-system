
package bank.management.system;

import javax.swing.*;
import javax.swing.JProgressBar;
import java.awt.*;
import java.awt.event.*;


public class ProgreesBar {
    
     ProgreesBar(){
        
     
     final JWindow w = new JWindow();
      w.setSize(600,400);
      w.setLocationRelativeTo(null);
       ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/OrdinaryWellinformedGosling-max-1mb.gif"));
        Image i5 = i4.getImage().getScaledInstance(700,480,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel label1 = new JLabel(i6);
        label1.setBounds(0,0,600,385);
        w.add(label1);
        
        JPanel panel = new JPanel();
        w.add(panel);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        
        JProgressBar progrees = new JProgressBar(0,100);
        w.add(BorderLayout.PAGE_END,progrees);
        progrees.setStringPainted(true);
        w.setVisible(true);
        int i = 0;
        while(i<=100){
            progrees.setValue(i);
            try
            {
                Thread.sleep(1000);
                
            }  catch(Exception e){
                
            } 
            i=i+10;
        } w.setVisible(false);
        new Login().setVisible(true);
         
       
      
     }
    
    
      
        
        
    public static void main(String args[]){
       new ProgreesBar();
       
    }
     
}   
        
        
         
        
        