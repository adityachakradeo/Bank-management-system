package bank.management.system;


import javax.swing.*;
import java.awt.*;

import java.awt.event.*;

public class SignupTwo extends JFrame implements ActionListener 
{
    
    JTextField pan,aadhar;
    JButton next;
    JRadioButton syes,sno,eyes,eno;
    JComboBox religion,category,occupation,education,income;
    String formno;
    SignupTwo(String formno){
       this.formno = formno;
        setLayout(null);
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");
     
     ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/bankicon.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel label = new JLabel(i3);
        label.setBounds(25,10,100,100);
         add(label);
     
     JPanel panel = new JPanel();
         panel.setSize(500,600);
         panel.setBackground(new Color(0,0,0,40));
         panel.setBounds(250,125,800,600);

     JLabel additionalDetails = new JLabel("Page 2: Additional details");
     additionalDetails.setFont(new Font("Raleway",Font.BOLD,22)); 
     additionalDetails.setBounds(500,80,400,30);
     add(additionalDetails);

     JLabel name = new JLabel("Religion:");
     name.setFont(new Font("Raleway",Font.BOLD,20)); 
     name.setBounds(300,140,100,30);
     add(name);
     
     String valReligion[]= {"Hindu","Muslim","Sikh","Christian","Other"};
     religion = new JComboBox(valReligion);
     religion.setBounds(500,140,400,30);
     religion.setBackground(Color.WHITE);
      religion.setSelectedItem(null);
     add(religion);
     
     
     JLabel fname = new JLabel("Category:");
     fname.setFont(new Font("Raleway",Font.BOLD,20)); 
     fname.setBounds(300,190,200,30);
     add(fname);
     
     String valcategory[] = {"General","OBC","SC","ST","Other"};
     category = new JComboBox(valcategory);
     category.setBounds(500,190,400,30);
     category.setBackground(Color.WHITE);
     category.setSelectedItem(null);
     add(category);
     
     JLabel dob = new JLabel("Income:");
     dob.setFont(new Font("Raleway",Font.BOLD,20)); 
     dob.setBounds(300,240,200,30);
     add(dob);
     
     String incomecategory[] = {"NULL","<1,50,000","<2,50,000","5,00,000","upto 10,00,000"};
     income= new JComboBox(incomecategory);
     income.setBounds(500,240,400,30);
     income.setBackground(Color.WHITE);
     income.setSelectedItem(null);
     add(income);
     
     
     JLabel gender = new JLabel("Educational");
     gender.setFont(new Font("Raleway",Font.BOLD,20)); 
     gender.setBounds(300,290,200,30);
     add(gender);
     
     JLabel email = new JLabel("Qualification:");
     email.setFont(new Font("Raleway",Font.BOLD,20)); 
     email.setBounds(300,315,200,30);
     add(email);
     
     String educationValues[] = {"Non -Graduation","Graduation","Post-Graduation","Doctorate","Others"};
     education= new JComboBox(educationValues);
     education.setBounds(500,315,400,30);
     education.setBackground(Color.WHITE);
     education.setSelectedItem(null);
     add(education);
     
     
     
       JLabel marital = new JLabel("Occupation:");
     marital.setFont(new Font("Raleway",Font.BOLD,20)); 
     marital.setBounds(300,390,200,30);
     add(marital);
     
      String occupationValues[] = {"Salried","Self-Employeed","Business","Student","Retired"};
     occupation= new JComboBox(occupationValues);
    occupation.setBounds(500,390,400,30);
     occupation.setBackground(Color.WHITE);
     occupation.setSelectedItem(null);
     add(occupation);
     
   
     
    JLabel address = new JLabel("PAN Number:");
    address.setFont(new Font("Raleway",Font.BOLD,20)); 
    address.setBounds(300,440,200,30);
    add(address);
    
     pan = new JTextField();
     pan.setFont(new Font("Raleway",Font.BOLD,14));
     pan.setBounds(500,440,400,30);
     add(pan);
    
     JLabel city = new JLabel("Adhar No:");
     city.setFont(new Font("Raleway",Font.BOLD,20)); 
     city.setBounds(300,490,200,30);
     add(city);
     
     aadhar= new JTextField();
     aadhar.setFont(new Font("Raleway",Font.BOLD,14));
     aadhar.setBounds(500,490,400,30);
     add(aadhar);
     
     JLabel state= new JLabel("Senior citizen");
     state.setFont(new Font("Raleway",Font.BOLD,20)); 
     state.setBounds(300,540,200,30);
     add(state);
     
     syes= new JRadioButton("Yes");
    syes.setBounds(500,540,100,30);
     add(syes);
     
     
     sno = new JRadioButton("No");
     sno.setBounds(650,540,100,30);
     add(sno);
     
     
     
     ButtonGroup maritalgroup = new ButtonGroup();
     maritalgroup.add(syes);
     maritalgroup.add(sno);
     
     
     JLabel pincode = new JLabel("Existing Account:");
     pincode.setFont(new Font("Raleway",Font.BOLD,20)); 
     pincode.setBounds(300,590,200,30);
     add(pincode);
     
    eyes = new JRadioButton("Yes");
    eyes.setBounds(500,590,100,30);
    
    add(eyes);
    
    eno = new JRadioButton("No");
    eno.setBounds(650,590,100,30);
     add(eno);
    
    ButtonGroup emaritalgroup = new ButtonGroup();
    emaritalgroup.add(eyes);
    emaritalgroup.add(eno);
     
     
     
     next = new JButton("Next");
     next.setBackground(Color.BLACK);
     next.setForeground(Color.WHITE);
     next.setFont(new Font("Raleway",Font.BOLD,14));
     next.setBounds(620,660,80,30);
     next.addActionListener(this);
     add(next);
     
     ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/bgimages.jpeg"));
        Image i5 = i4.getImage().getScaledInstance(1600,800,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel label1 = new JLabel(i6);
        label1.setBounds(0,0,1600,800);
         add(label1);
         label1.add(panel);
     
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setSize(1600,800);
    setLocation(350,10);
    setVisible(true);
}
    public void actionPerformed(ActionEvent ae){
        
        String sreligion= (String)religion.getSelectedItem();
        String scategory = (String)category.getSelectedItem();
        String sincome = (String)income.getSelectedItem();
        String seducation = (String)education.getSelectedItem();
        String soccupation= (String)occupation.getSelectedItem();
        
        
        String seniorcitizen = null;
        if(syes.isSelected()){
            seniorcitizen = "Yes";
        } else if(sno.isSelected()){
            seniorcitizen = "No";
        }
        
        
        String existingaccount= null;
        if(eyes.isSelected()){
            existingaccount = "Yes";
        } else if(eno.isSelected()){
           existingaccount = "NO";
            
        } 
        String span = pan.getText();
        String saadhar = aadhar.getText();
       
        
        try {
            if(religion.getSelectedIndex()== -1){
                 JOptionPane.showMessageDialog(null,"Religion is Required");
            }else if(category.getSelectedIndex()== -1){
                 JOptionPane.showMessageDialog(null,"Category is Required");
            }else if(occupation.getSelectedIndex()== -1){
                 JOptionPane.showMessageDialog(null,"Information is Required");
            }else if(education.getSelectedIndex()== -1){
                 JOptionPane.showMessageDialog(null,"Information is Required");
            }else if(income.getSelectedIndex()== -1){
                 JOptionPane.showMessageDialog(null,"Selection is Required");
            }
            else if(span.equals("")){
                 JOptionPane.showMessageDialog(null,"Pan number is required");
                 
             } else if(saadhar.equals("")){
                 JOptionPane.showMessageDialog(null,"Aaadhar Number is required");
             
             }else if(syes.isSelected() == false && sno.isSelected() == false ){
                JOptionPane.showMessageDialog(null,"Selection is Required");
            }else if(eyes.isSelected() == false && eno.isSelected() == false ){
                JOptionPane.showMessageDialog(null,"Selection is Required");
            
            }
            else{
                Conn c = new Conn();
                String query ="insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+soccupation+"','"+span+"','"+saadhar+"','"+seniorcitizen+"','"+existingaccount+"')";
                c.s.executeUpdate(query);
                
                setVisible(false);
                new SignupThree(formno).setVisible(true);
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
       
        
    }
           
    
    public static void main(String args[]){
        new SignupTwo("");
    }
}
