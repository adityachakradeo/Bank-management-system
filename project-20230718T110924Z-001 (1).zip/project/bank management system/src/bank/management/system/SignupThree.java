
package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class SignupThree extends JFrame implements ActionListener{
    
    JRadioButton r1,r2,r3,r4;
    JCheckBox c1,c2,c3,c4,c5,c6,c7;
    JButton submit,cancel;
    String formno;
    SignupThree(String formno){
        this.formno = formno;
        setLayout(null);
         ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/bankicon.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100,80,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel label = new JLabel(i3);
        label.setBounds(70,10,100,100);
         add(label);
         JPanel panel = new JPanel();
         panel.setSize(500,600);
         panel.setBackground(new Color(0,0,0,30));
         panel.setBounds(250,80,800,700);
        
        JLabel l1 = new JLabel("Page 3: Account Details");
        l1.setFont(new Font("Raleway",Font.BOLD,22));
        l1.setBounds(500,40,400,30);
        add(l1);
        
        JLabel type = new JLabel("Account Type");
        type.setFont(new Font("Raleway",Font.BOLD,22));
       type.setBounds(300,100,200,30);
        add(type);
        
        r1 = new JRadioButton("Saving Account");
        r1.setFont(new Font("Raleway",Font.BOLD,16));
        r1.setBounds(300,150,250,20);
        add(r1);
        
        r2 = new JRadioButton("Fixed Deposit Account");
        r2.setFont(new Font("Raleway",Font.BOLD,16));
        r2.setBounds(700,150,250,20);
        add(r2);
        
        r3 = new JRadioButton("Current Account");
        r3.setFont(new Font("Raleway",Font.BOLD,16));
        r3.setBounds(300,200,250,20);
        add(r3);
        
        r4 = new JRadioButton("Recuring Deposit Account");
        r4.setFont(new Font("Raleway",Font.BOLD,16));
        r4.setBounds(700,200,260,20);
        add(r4);
        
        ButtonGroup groupaccount = new ButtonGroup();
        groupaccount.add(r1);
        groupaccount.add(r2);
        groupaccount.add(r3);
        groupaccount.add(r4);
           
        JLabel card = new JLabel("Card Number");
        card.setFont(new Font("Raleway",Font.BOLD,22));
        card.setBounds(300,250,200,20);
        add(card);

         JLabel number = new JLabel("XXXX-XXXX-XXXX-4184");
        number.setFont(new Font("Raleway",Font.BOLD,22));
        number.setBounds(500,250,300,20);
        add(number);
        
        JLabel carddetail = new JLabel("This is your 16 Digit Card No");
       carddetail.setFont(new Font("Raleway",Font.BOLD,12));
       carddetail.setBounds(300,270,300,20);
        add(carddetail);
        
          JLabel pin = new JLabel("Pin Number");
        pin.setFont(new Font("Raleway",Font.BOLD,22));
        pin.setBounds(300,330,200,20);
        add(pin);

         JLabel pnumber = new JLabel("XXXX");
        pnumber.setFont(new Font("Raleway",Font.BOLD,22));
        pnumber.setBounds(500,330,300,20);
        add(pnumber);
        
          JLabel pindetail = new JLabel("This is your 4 Digit Pin");
      pindetail.setFont(new Font("Raleway",Font.BOLD,12));
      pindetail.setBounds(300,350,300,20);
        add(pindetail);
        
         JLabel services= new JLabel("Services Required");
       services.setFont(new Font("Raleway",Font.BOLD,22));
       services.setBounds(300,400,300,20);
        add(services);
        
        c1 = new JCheckBox("ATM CARD");
        c1.setFont(new Font("Raleway",Font.BOLD,16));
        c1.setBounds(300,450,200,20);
        add(c1);
        
        c2 = new JCheckBox("Internet Banking");
        c2.setFont(new Font("Raleway",Font.BOLD,16));
        c2.setBounds(700,450,200,20);
        add(c2);
        
        c3 = new JCheckBox("Mobile Banking");
        c3.setFont(new Font("Raleway",Font.BOLD,16));
        c3.setBounds(300,500,200,30);
        add(c3);
        
        c4 = new JCheckBox("Email & SMS Alerts");
        c4.setFont(new Font("Raleway",Font.BOLD,16));
        c4.setBounds(700,500,200,20);
        add(c4);
        
        c5= new JCheckBox("Cheque Book");
        c5.setFont(new Font("Raleway",Font.BOLD,16));
        c5.setBounds(300,550,200,20);
        add(c5);
        
        c6 = new JCheckBox("E-Statement");
        c6.setFont(new Font("Raleway",Font.BOLD,16));
        c6.setBounds(700,550,200,20);
        add(c6);
        
        c7 = new JCheckBox("I hereby declare the above details are correct");
        c7.setFont(new Font("Raleway",Font.BOLD,12));
        c7.setBounds(300,600,600,20);
        add(c7);
        
        submit = new JButton("submit");
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.setFont(new Font("Raleway",Font.BOLD,14));
        submit.setBounds(300,650,100,30);
        submit.addActionListener(this);
        add(submit);
        
        cancel = new JButton("Cancel");
       cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.setFont(new Font("Raleway",Font.BOLD,14));
        cancel.setBounds(700,650,100,30);
        cancel.addActionListener(this);
        add(cancel);
        
         ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/bgimages.jpeg"));
        Image i5 = i4.getImage().getScaledInstance(1600,800,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel label1 = new JLabel(i6);
        label1.setBounds(0,0,1600,800);
         add(label1);
         label1.add(panel);
        
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600,800);
        setLocation(350,0);
        setVisible(true);
        
    
    }
      public void actionPerformed(ActionEvent ae){
          if(ae.getSource()== submit){
              String accountType = null;
              if(r1.isSelected()){
                  accountType = "Saving Account";
              }
              else if(r2.isSelected()){
                  accountType ="Fixed Deposit Account";
                  
              } else if(r3.isSelected()){
                  accountType = "Current Account";
              } else if(r4.isSelected()){
                  accountType ="Recurring Deposit Account";
              }
              
              Random random = new Random();
              String cardnumber = "" + Math.abs((random.nextLong() % 90000000L)+ 5040936000000000L);
              
              String pinnumber = "" + Math.abs((random.nextLong() % 9000L) + 1000L);
              
              String facility ="";
              if(c1.isSelected()){
                  facility = facility + " ATM Card";
              }else if(c2.isSelected()){
                  facility = facility +" Internet Banking";
              } else if(c3.isSelected()){
                   facility = facility + " Mobile Banking";
              } else if(c4.isSelected()){
                facility = facility + " Email & Sms Alerts";
              } else if(c5.isSelected()){
                  facility = facility + " Cheque Book";
              } else if(c6.isSelected()){
                  facility = facility +" E-Statement";
              
              }
              
              try{
                  if(r1.isSelected() == false && r2.isSelected() == false && r3.isSelected()== false && r4.isSelected()== false){
                JOptionPane.showMessageDialog(null,"Selection is Required");
            }else if(c1.isSelected() == false && c2.isSelected() == false && c3.isSelected()== false && c4.isSelected()== false && c5.isSelected()== false && c6.isSelected()== false && c7.isSelected()== false){
                JOptionPane.showMessageDialog(null,"Selection is Required");
            }
                  else {
                            Conn conn = new Conn();
                      String query1 = "insert into signupthree values('"+formno+"','"+accountType+"','"+cardnumber+"','"+pinnumber+"','"+facility+"')";
                      String query2 = "insert into login values('"+formno+"','"+cardnumber+"','"+pinnumber+"')";
                      conn.s.executeUpdate(query1);
                      conn.s.executeUpdate(query2);
                      
                      JOptionPane.showMessageDialog(null, "Card Number:" + cardnumber +"\n Pin:" +pinnumber);
                 
                  }  
                  setVisible(false);
                  new Deposit(pinnumber).setVisible(false);
                  
                  
              }catch(Exception e){
                  System.out.println(e);
              }
              


          } else if(ae.getSource()== cancel){
              setVisible(false);
              new Login().setVisible(true);
              
          }
      }
    public static void main(String args[]){
        new SignupThree("");  
    }
}
