
package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
public class Login extends JFrame implements ActionListener{
    
    JButton login,signup,clear;
    JTextField cardTextField;
    JPasswordField pinTextField;
   
    
    Login()
    {
        setTitle("AUTOMATED TELLER MACHINE");
        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/bankicon.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100,100,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel label = new JLabel(i3);
        label.setBounds(300,10,100,100);
         add(label);
         
         JPanel panel = new JPanel();
         panel.setSize(400,350);
         panel.setBackground(new Color(0,0,0,40));
         panel.setBounds(325,125,600,500);
         
         JLabel text = new JLabel("Welcome to ATM");
         text.setFont(new Font("Osward",Font.BOLD,38));
         text.setBounds(450,40,400,40);
         add(text);
         
         JLabel cardno = new JLabel("Card no");
         cardno.setFont(new Font("Raleway",Font.BOLD,28));
         cardno.setBounds(425,250,150,40);
         add(cardno);
         
         cardTextField = new JTextField();
         cardTextField.setBounds(580,250,230,30);
         cardTextField.setFont(new Font("Arial",Font.BOLD,14));
         add(cardTextField);
         
         JLabel pin = new JLabel("Pin no");
         pin.setFont(new Font("Raleway",Font.BOLD,28));
         pin.setBounds(425,300,150,40);
         add(pin);
         
         pinTextField = new JPasswordField ();
         pinTextField.setBounds(580,300,230,30);
           pinTextField.setFont(new Font("Arial",Font.BOLD,14));
         add(pinTextField);
         
      
         
         login = new JButton("SIGN IN");
         login.setBounds(475,375,100,40);
         login.setBackground(Color.BLACK);
         login.setForeground(Color.WHITE);
         login.addActionListener(this);
         add(login);
         
          clear= new JButton("CLEAR");
         clear.setBounds(650,375,100,40);
         clear.setBackground(Color.BLACK);
         clear.setForeground(Color.WHITE);
         clear.addActionListener(this);
         add(clear);
         
         signup= new JButton("SIGN UP");
         signup.setBounds(500,450,230,40);
         signup.setBackground(Color.BLACK);
         signup.setForeground(Color.WHITE);
         signup.addActionListener(this);
         add(signup);
          
        

                 

         
         ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/bgimages.jpeg"));
        Image i5 = i4.getImage().getScaledInstance(1600,800,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel label1 = new JLabel(i6);
        label1.setBounds(0,0,1600,800);
         add(label1);
         label1.add(panel);
         
         
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1600,800);
        setVisible(true);
        setLocation(350,200);
    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == clear){
            cardTextField.setText("");
            pinTextField.setText("");
 
        }
        else if(ae.getSource() == login){
            Conn conn = new Conn();
            String cardnumber = cardTextField.getText();
            String pinnumber = pinTextField.getText();
            String query = "select * from login where cardnumber='"+cardnumber+"'and pin='"+pinnumber+"'";
            try{
                ResultSet rs=conn.s.executeQuery(query);
                if(rs.next()){
                    setVisible(false);
                    new Transactions(pinnumber).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null,"Incorrect Card Number and Pin");
                }
                
            } catch(Exception e){
                System.out.println(e);
            }
            
        } else if(ae.getSource() == signup){
            setVisible(false);
            new SignupOne().setVisible(true);
        }
    }
    public static void main(String args[])
    {
        new Login();
    }
          
}
