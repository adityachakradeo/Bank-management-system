
package bank.management.system;
import java.sql.*;

public class Conn {
    Connection c;
    Statement s;
    public Conn()
    {
        try{
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql:bankmanagementsystem","postgres","abcd1234");
            s = c.createStatement();
        } catch(Exception e){
            System.out.println(e);
        }
    }
    
}
